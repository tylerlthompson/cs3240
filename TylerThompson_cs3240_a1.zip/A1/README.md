# Description
Assignment 1 for CS3240 System Programming Concepts 
jan 15, 2020
Generates a large array of random doubles and sorts them using a threaded merge-insert sort.
Process is then repeated for a linked list.
Results are written to array.csv and linked.csv


# Compilation
To compile the program, run the following from the root directory of the project. `make a1`

The project can also be cleaned with `make clean`

# Execution
Both array and linked list sorting can be exectued with `make run`
